# Dingbats Keyboard (Android IME)
This is a minimal custom keyboard that types Unicode dingbat symbols. Build in Android Studio:
1) Open the project folder.
2) Let Android Studio create/upgrade the Gradle wrapper if prompted.
3) Build > Build APK(s). Install the debug APK on your phone.
4) Enable in Settings > System > Languages & input > On-screen keyboard > Manage keyboards.
5) Switch with the 🌐 key.
Optional: Put a `wingdings.ttf` in `app/src/main/assets/` to make key labels look like Wingdings (visual only).
