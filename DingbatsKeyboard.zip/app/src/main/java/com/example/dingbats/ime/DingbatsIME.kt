package com.example.dingbats.ime

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.view.View
import android.view.inputmethod.InputConnection
import android.inputmethodservice.KeyboardView
import android.graphics.Typeface
import com.example.dingbats.R

class DingbatsIME : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: TypefaceKeyboardView
    private lateinit var keyboard: Keyboard

    override fun onCreateInputView(): View {
        val v = layoutInflater.inflate(R.layout.keyboard_view, null) as TypefaceKeyboardView
        keyboardView = v
        keyboard = Keyboard(this, R.xml.keyboard_dingbats)
        keyboardView.keyboard = keyboard
        keyboardView.setOnKeyboardActionListener(this)

        // Optional Wingdings TTF for key labels only (visual)
        try {
            val tf = Typeface.createFromAsset(assets, "wingdings.ttf")
            keyboardView.setTypeface(tf)
        } catch (_: Exception) {
            keyboardView.setTypeface(null)
        }
        return keyboardView
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic: InputConnection = currentInputConnection ?: return
        when (primaryCode) {
            Keyboard.KEYCODE_DELETE -> ic.deleteSurroundingText(1, 0)
            Keyboard.KEYCODE_DONE, 10 -> ic.commitText("\n", 1)
            -2 -> switchToNextInputMethod(false) // globe
            else -> {
                val txt = String(Character.toChars(primaryCode))
                ic.commitText(txt, 1)
            }
        }
    }
    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) { text?.let { currentInputConnection?.commitText(it, 1) } }
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}
}
