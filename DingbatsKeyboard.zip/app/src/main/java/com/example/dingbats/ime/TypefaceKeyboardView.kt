package com.example.dingbats.ime

import android.content.Context
import android.graphics.Canvas
import android.graphics.Typeface
import android.util.AttributeSet
import android.inputmethodservice.KeyboardView

class TypefaceKeyboardView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : KeyboardView(context, attrs) {

    private var customTypeface: Typeface? = null

    fun setTypeface(tf: Typeface?) {
        customTypeface = tf
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        try {
            val field = KeyboardView::class.java.getDeclaredField("mPaint")
            field.isAccessible = true
            val paint = field.get(this) as android.graphics.Paint
            customTypeface?.let { paint.typeface = it }
        } catch (_: Exception) {}
        super.onDraw(canvas)
    }
}
